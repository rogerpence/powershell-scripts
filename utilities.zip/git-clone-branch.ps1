if ($args.length -lt 2) {
    write-host git-clone-branch '$branch' '$repo'
    exit
}

$branch = $args[0]
$repo = $args[1]

git clone --single-branch --branch $($branch) $($repo)