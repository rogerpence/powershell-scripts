

if ($args.length -eq 0) {
    write-host no args
    exit
}

write-host $args.length